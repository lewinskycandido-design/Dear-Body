# Validation — 23 September 2026

## Result

The package is ready for upload as an unpublished Shopify theme and for file-by-file copy/paste. The published store was not modified by this build. Shopify backend execution has not been tested.

## Structure and code

- 43 packaged theme files: 34 text files and 9 JPG assets.
- 32 Liquid/JSON files parsed by Shopify's official Liquid HTML parser or JSON parser. CSS/JavaScript are additional text files.
- Every JSON template/group references an existing section. Every bundled image exists. Section schemas parse and setting IDs are unique.
- The ZIP opens successfully and has Shopify folders at its root, including `layout/theme.liquid`.
- Header, footer, homepage sections and priority-product blocks are editable through Shopify section/settings schemas.
- Preview builder renders 14 routes from actual Liquid sources, including default-page handle mapping for story/contact. There are no substituted fallback templates.
- All 17 isolated runtime/Liquid commerce tests pass. Tests execute the actual theme JavaScript and product-card Liquid against synthetic fixtures: paid/free/sold-out/invalid variant states, merchant-formatted currency, native submission guards, media switching and video pause, keyboard menu dismissal, and mixed-price cards.

## Browser checks

Reviewed the homepage at 1440px desktop and 390px/320px mobile widths. No horizontal overflow or broken images were observed. The mobile source selects the dedicated portrait hero; copy sits above the photograph.

Visually inspected hero, all six final product cards, editorial section, story, newsletter, footer, mobile product page, cart and contact page. Open/close/Escape behavior of the mobile menu passed. Product media button switched the visible gallery image. The unavailable preview product and cart checkout controls are correctly disabled.

The code browser's file selector and Copy code button worked; it reported a successful copy of the selected hero source. Generated code browser and theme ZIP contain the same source files.

## Publication checks

Six exact priority names, original white/black label families and matching packaging colors are retained. Final packshots share cream backgrounds and consistent framing. Home heroes show all six fragrances. See `ASSET_QA.md` for the image audit.

The approved palette is used. System typography and typed wordmarks are placeholders until licensed brand webfonts and official logo files are supplied. No unsupported prices, stock promises or scent-note claims were added.

## Practical limits

The local preview uses an explicitly labeled mock catalog with unavailable/zero-price products and intercepts forms. It is not a Shopify checkout simulator. It does not send contact messages or subscriptions.

Shopify upload acceptance, authenticated checkout/payment, real inventory, storefront app integrations, customer accounts, email delivery and currency localization must be checked in the Shopify draft before publication. Existing app customizations are not included in this standalone theme.

## Reproduce

```sh
cd preview
npm ci
npm run build
node verify-commerce.mjs
```

From the package directory, `python3 package-theme.py` regenerates the ZIP, source browser and SHA-256 manifest. The preview launch command is `npm run preview` from `preview/`.
