# Asset and publication QA

Reviewed and refined 2026-09-23. Inspected the actual theme JPEGs individually, compared product identities with owner photographs `IMG_20260923_163159.jpg`, `IMG_20260923_163311.jpg`, `IMG_20260923_162213.jpg`, `IMG_20260923_162432.jpg` and `IMG_20260923_162544.jpg`, and checked image dimensions, byte sizes and current hero/font markup. The three black-label card images were regenerated with built-in imagegen to match the cream studio treatment and bring Oud Mirage's liquid closer to its source color. Their final 900-pixel quality-87 JPEGs were individually inspected, copied into the theme assets and verified byte-for-byte. No theme code was edited in this asset task. The root implementation task separately verified the desktop hero at 1440px without text/cap/label overlap; other rendered layout checks belong to that task.

## Asset results

| Theme asset | Pixels | Bytes | Review |
| --- | --- | ---: | --- |
| db-hero-desktop.jpg | 1774 × 887 | 337843 | PASS: all six distinct bottles, correct printed names and white/black label groups; full caps and bases. |
| db-hero-mobile.jpg | 1122 × 1402 | 382917 | PASS: six bottles in two clear rows; every label remains visible; spelling and Charme accent preserved. |
| db-mojito-metallique.jpg | 900 × 900 | 139969 | PASS: MOJITO METALLIQUE, ivory labels, yellow canister, golden liquid. |
| db-amber-oud-silk.jpg | 900 × 900 | 131354 | PASS: AMBER OUD SILK, ivory labels, peach canister, pale champagne liquid. |
| db-mistened-narcissus.jpg | 900 × 900 | 134941 | PASS: MISTENED NARCISSUS, ivory labels, lilac canister, nearly clear liquid. |
| db-oud-mirage.jpg | 900 × 900 | 89695 | PASS after refinement: OUD MIRAGE, black labels, medium-blue canister and transparent pale-blue liquid; saturated cyan liquid corrected. |
| db-charme-envoutant.jpg | 900 × 900 | 102667 | PASS after refinement: CHARME ENVOÛTANT, black labels, vivid orange canister and amber-orange liquid; clean cream composition matches the collection. |
| db-rtulle-and-satin.jpg | 900 × 900 | 99997 | PASS after refinement: RTULLE & SATIN, black labels, turquoise canister and transparent pale-turquoise liquid. The unusual initial R is preserved exactly. |

All eight files decode as RGB JPEG. Labels are sharp at these asset sizes; silhouettes, package closure, caps and contact shadows are intact. No duplicated or omitted scent, extra bottle, cut-off label or spelling error was found. Small PARFUM/LONDON text naturally becomes tiny on narrow product cards; live product titles should carry identification at that size.

## Publication fit

The home-display heroes are warm, vibrant and approachable: cream daylight, natural wood, a burgundy tray and orange lamp tie the six products to the brand palette. They present the collection without treating one fragrance as the only hero. After refinement, all six cards share the same cream background, framing, soft light, natural contact shadow and bottle/canister placement. The lively packaging colors distinguish scents within a consistent product grid. No blocking identity or publication-fit issue remains in the eight reviewed images.

The refined PNG masters and WebP copies are in `output/website/redesign-assets/` as `{oud-mirage,charme-envoutant,rtulle-and-satin}-website-packshot-v02`. Prompt provenance and checksums are recorded there in `BLACK_LABEL_PACKSHOT_PROMPTS_V02.json` and `BLACK_LABEL_PACKSHOT_FILES_V02.json`. The six card masters remain native 1254 × 1254; no product artwork was deterministically retouched during export.

## Hero placement

- Desktop: preserve the complete 2:1 image. Do not center-crop it into a portrait, square or narrower frame; use the supplied mobile composition instead. The product group occupies approximately x=30–84%, y=28–71%. Keep live copy in the calm region around x=4–27%, y=12–56%; the tray enters the lower-left near y=60%.
- Mobile: show the complete near-4:5 image with live copy above it. All six labels and bottle edges remain safe. Avoid a short fixed-height cover crop or overlaying text over the upper product row.
- Current markup switches to the mobile asset at 700px; CSS stacks hero copy above the image by 900px, uses 2:1 desktop and 4:5 mobile ratios. These match the assets. The root task reports the desktop copy does not overlap caps or labels at 1440px. Keep actual text/button bounds clear of the first bottle when changing copy or sizing. `object-fit:cover` is harmless at the current matching ratios, but arbitrary theme image replacements need their own crop review.

## Brand implementation limits

The theme currently uses `Helvetica Neue`, `Helvetica`, `Arial`, sans-serif for both display and body. This is a documented fallback; it does not reproduce the official Cenzo Flare Bold display face or Helvetica Now Display body face. Licensed brand webfonts have not been installed.

The header supports an uploaded logo through `settings.logo`. Without one, it displays typeset DEAR BODY / PHILIPPINES text. The footer currently always uses this typeset wordmark. This text treatment is a fallback, not the exact supplied brand-logo artwork; use the official asset to achieve full logo fidelity.

No ingredient, performance or fragrance-note claims were inferred during this image audit.
