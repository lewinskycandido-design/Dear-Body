# DearBody — A Scent Journey

A complete custom Shopify storefront using DearBody's burgundy and cream identity, the six priority fragrances, and a home-collection hero. The theme includes homepage, catalog, product gallery and variant selection, bag, Shopify checkout handoff, story, contact, newsletter, generic content pages, password page and 404 page.

## Install the full website

1. In Shopify, open **Online Store → Themes → Import theme → Upload zip file** and upload `DearBody-Shopify-Theme.zip`. This adds an unpublished theme. Rename it **Dear Body — A Scent Journey**.
2. Open **Customize** on the uploaded theme. Under **DearBody priority scents**, connect each of the six blocks to its correct Shopify product. The bundled artwork and scent names are already present.
3. Open **Theme settings → Brand artwork** and add the official logo, a light footer logo, and favicon when available. Select your navigation menus in the header/footer, or use the built-in links.
4. Create or open pages with the exact handles `our-story` and `contact`. The default page template automatically gives these handles their designed story and contact layouts. The dedicated **our-story** / **contact** templates are also included if you prefer assigning them explicitly. Shopify lists assignable templates from the live theme; the automatic handle mapping lets the draft work before publication.
5. Add approved product descriptions, actual prices, inventory, delivery settings and store policies in Shopify. Upload the matching `assets/db-…jpg` packshot to each product's media so catalog and product pages use the same imagery as the homepage. Keep products that are not ready as drafts.
6. Use the theme's **Preview** action to inspect the storefront. Publish only when the catalog and operational settings are ready.

The ZIP is a full theme. Upload it as a theme, not into a Custom Liquid block. It does not change the currently published store or overwrite product data.

## Copy and paste into the existing draft instead

Open `COPY-PASTE-CODE.html` for every source file with individual **Copy code** buttons. The source folder is `dearbody/`.

For **Dear Body — Website Build**, duplicate the draft first, then use **… → Edit code** on the duplicate. Upload the 9 JPG files and create or replace the files shown in the source browser, preserving each folder and filename. The complete storefront requires all files, including `layout/theme.liquid`, section groups, templates, CSS and JavaScript. Replacing `templates/index.json`, the shared layout or settings replaces that draft's corresponding structure/settings. A fresh ZIP upload is the simplest way to preserve the old draft intact.

Binary photographs cannot be pasted as Liquid code: upload them to the theme's **assets** folder. Do not paste this whole package into one Custom Liquid field. That field cannot install product/cart templates, shared navigation or asset files.

## Priority product mapping

| Product | Default handle | Bundled image |
|---|---|---|
| Mojito Metallique | `mojito-metallique` | `db-mojito-metallique.jpg` |
| Amber Oud Silk | `amber-oud-silk` | `db-amber-oud-silk.jpg` |
| Mistened Narcissus | `mistened-narcissus` | `db-mistened-narcissus.jpg` |
| Oud Mirage | `oud-mirage` | `db-oud-mirage.jpg` |
| Charme Envoûtant | `charme-envoutant` | `db-charme-envoutant.jpg` |
| Rtulle & Satin | `rtulle-and-satin` | `db-rtulle-and-satin.jpg` |

Use the product picker if your actual handles differ. The homepage first uses the chosen product, then attempts the handle. A missing/unpublished product keeps its image/name and “Available soon”; it does not create a broken product link. Homepage bundled artwork is intentional; clear the block's “Bundled image filename” to use the chosen product's featured image instead.

The all-fragrances collection and product pages use real Shopify catalog data. The ZIP does not create products or make draft products available on the Online Store sales channel.

## Behavior and content

- Native Shopify product forms add the selected variant and quantity to the cart. Native cart forms update quantities, remove line items and hand off to Shopify checkout.
- Zero-price and unavailable variants cannot be purchased through this theme's controls. This is a storefront guard, not a server-side product restriction. Keep unapproved products unpublished; do not rely on theme code to restrict other sales channels or direct cart API calls.
- No prices, stock counts, shipping promises, discounts, unsupported scent notes, concentration or size claims are invented. Product descriptions come from Shopify. Ingredients/care render only when corresponding `custom.ingredients` / `custom.care` metafields are populated.
- Contact and newsletter use Shopify's own form handling. Confirm store email/marketing settings in Shopify. No third-party form service is required.
- Policies appear only when their bodies exist in Shopify. Checkout styling, payment methods, tax, delivery and order emails are managed separately in Shopify.
- This is a lean custom theme, not a Shopify Theme Store submission. Existing app-specific snippets, app blocks, subscriptions, customer-account templates and advanced catalog filters are not migrated from Horizon; review any installed storefront apps before switching themes.

## Publication identity

Palette: burgundy `#5c0006`, red `#9a1106`, burnt orange `#d46601`, golden tan `#e9a250`, cream `#f4e3cb`. Photography preserves the six real product identities and original light/dark label families.

Typography currently uses Helvetica Neue/Helvetica/Arial. These are deliberate system-font fallbacks. Licensed Cenzo Flare Bold and Helvetica Now Display webfonts were not supplied or embedded. Header/footer type is a text placeholder for the official DearBody artwork; replace it through Brand artwork when the approved logo is available.

The desktop hero remains 2:1 and switches to a dedicated 4:5 composition on mobile. Mobile copy sits above the photo so all six bottles remain visible. Do not crop the images into a narrow vertical background or stretch them.

## Local preview

The preview renders the same Liquid source with mock catalog data. It uses six real scent names and packaged imagery but marks every product unavailable while business data is unconfirmed. Its notice and form interception exist only in the preview; they are absent from the Shopify ZIP.

Run from `preview/`:

```sh
npm ci
npm run preview
```

Then open `http://127.0.0.1:4173`. `npm run build` regenerates preview pages and validates Liquid syntax with Shopify's parser. Local checks cannot validate live payment processing, Shopify mail delivery or real inventory.

## Source references

[Shopify theme upload](https://help.shopify.com/en/manual/online-store/themes/adding-themes) · [Theme architecture](https://shopify.dev/docs/storefronts/themes/architecture) · [Native forms](https://shopify.dev/docs/api/liquid/tags/form) · [JSON templates](https://shopify.dev/docs/storefronts/themes/architecture/templates/json-templates)
